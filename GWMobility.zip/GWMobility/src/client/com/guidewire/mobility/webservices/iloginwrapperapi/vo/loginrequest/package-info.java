@javax.xml.bind.annotation.XmlSchema(namespace = "http://guidewire.com/mobility/webservices/ILoginWrapperAPI/vo/LoginRequest", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package client.com.guidewire.mobility.webservices.iloginwrapperapi.vo.loginrequest;
